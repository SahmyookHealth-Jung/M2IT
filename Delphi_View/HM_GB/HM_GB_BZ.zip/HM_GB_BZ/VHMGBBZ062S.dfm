object Form51: TForm51
  Left = 2103
  Top = 64
  Width = 1542
  Height = 859
  Caption = #54801#47141#48337#50896' '#51648#44553#51204#54364' '#44288#47532' [VHMGBBZ062S]'
  Color = clWhite
  Font.Charset = ANSI_CHARSET
  Font.Color = clWindowText
  Font.Height = -13
  Font.Name = #45208#45588#44256#46357
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 15
  object FlatPanel1: TFlatPanel
    Left = 8
    Top = 8
    Width = 1401
    Height = 729
    ParentColor = True
    TabOrder = 0
    UseDockManager = True
    object FlatPanel4: TFlatPanel
      Left = 921
      Top = 70
      Width = 479
      Height = 33
      ParentColor = True
      TabOrder = 6
      UseDockManager = True
      object FlatLabel8: TFlatLabel
        Left = 5
        Top = 4
        Width = 54
        Height = 25
        Alignment = taRightJustify
        TextBorder = 2
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #44144#47000#52376
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = True
        ShowEssential = False
      end
    end
    object FlatPanel6: TFlatPanel
      Left = 1
      Top = 70
      Width = 920
      Height = 33
      ParentColor = True
      TabOrder = 5
      UseDockManager = True
      object FlatLabel6: TFlatLabel
        Left = 5
        Top = 4
        Width = 66
        Height = 25
        Alignment = taRightJustify
        TextBorder = 2
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #54801#47141#48337#50896
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = True
        ShowEssential = False
      end
    end
    object FlatPanel5: TFlatPanel
      Left = 1
      Top = 37
      Width = 1399
      Height = 33
      ParentColor = True
      TabOrder = 3
      UseDockManager = True
    end
    object FlatPanel3: TFlatPanel
      Left = 1
      Top = 1
      Width = 1399
      Height = 36
      ParentColor = True
      TabOrder = 0
      UseDockManager = True
      object FlatLabel3: TFlatLabel
        Left = 7
        Top = 5
        Width = 65
        Height = 25
        Alignment = taRightJustify
        TextBorder = 0
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #54644#45817#45380#50900
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = False
        ShowEssential = True
      end
      object FlatLabel1: TFlatLabel
        Left = 145
        Top = 4
        Width = 17
        Height = 25
        Alignment = taRightJustify
        TextBorder = 0
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #45380
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = False
        ShowEssential = False
      end
      object FlatLabel2: TFlatLabel
        Left = 241
        Top = 4
        Width = 65
        Height = 25
        Alignment = taRightJustify
        TextBorder = 0
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #54801#47141#48337#50896
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = False
        ShowEssential = False
      end
      object FlatLabel5: TFlatLabel
        Left = 213
        Top = 4
        Width = 16
        Height = 25
        Alignment = taRightJustify
        TextBorder = 0
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #50900
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = False
        ShowEssential = False
      end
      object FlatLabel4: TFlatLabel
        Left = 568
        Top = 5
        Width = 65
        Height = 25
        Alignment = taRightJustify
        TextBorder = 0
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #44144#47000#52376#47749
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = False
        ShowEssential = False
      end
      object FlatLabel7: TFlatLabel
        Left = 897
        Top = 4
        Width = 65
        Height = 25
        Alignment = taRightJustify
        TextBorder = 0
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #52376#47532#49345#53468
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = False
        ShowEssential = True
      end
      object FlatButton1: TFlatButton
        Left = 1321
        Top = 7
        Width = 72
        Height = 23
        Color = clSilver
        Caption = #51312#54924
        ParentColor = False
        TabOrder = 0
      end
      object FlatComboBox1: TFlatComboBox
        Left = 404
        Top = 6
        Width = 157
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 1
        ItemIndex = -1
      end
      object FlatSpinEditInteger2: TFlatSpinEditInteger
        Left = 79
        Top = 6
        Width = 64
        Height = 23
        ColorFlat = clWhite
        AutoSize = False
        MaxValue = 0
        MinValue = 0
        TabOrder = 2
        Value = 2026
      end
      object FlatSpinEditInteger1: TFlatSpinEditInteger
        Left = 167
        Top = 6
        Width = 48
        Height = 23
        ColorFlat = clWhite
        AutoSize = False
        MaxValue = 0
        MinValue = 0
        TabOrder = 3
        Value = 12
      end
      object FlatEdit5: TFlatEdit
        Left = 311
        Top = 6
        Width = 91
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 4
      end
      object FlatEdit1: TFlatEdit
        Left = 639
        Top = 6
        Width = 91
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 5
      end
      object FlatComboBox3: TFlatComboBox
        Left = 732
        Top = 6
        Width = 157
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 6
        ItemIndex = -1
      end
      object FlatComboBox4: TFlatComboBox
        Left = 967
        Top = 6
        Width = 106
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 7
        Text = #51204#52404
        ItemIndex = -1
      end
      object FlatCheckBox16: TFlatCheckBox
        Left = 1087
        Top = 6
        Width = 74
        Height = 22
        Caption = #44036#51060#52636#47141
        TabOrder = 8
        TabStop = True
      end
      object FlatCheckBox1: TFlatCheckBox
        Left = 1167
        Top = 6
        Width = 114
        Height = 22
        Caption = #45236#50669#54364' '#46041#49884#51064#49604
        TabOrder = 9
        TabStop = True
      end
    end
    object FlatComboBox2: TFlatComboBox
      Left = 1322
      Top = 40
      Width = 72
      Height = 23
      Color = clWindow
      ItemHeight = 15
      TabOrder = 1
      Text = '  Action'
      ItemIndex = -1
    end
    object FlatPanel2: TFlatPanel
      Left = 1
      Top = 103
      Width = 920
      Height = 490
      ParentColor = True
      TabOrder = 4
      UseDockManager = True
      object AdvStringGrid3: TAdvStringGrid
        Left = 1
        Top = 1
        Width = 918
        Height = 488
        Cursor = crDefault
        Align = alClient
        ColCount = 11
        DefaultRowHeight = 25
        DefaultDrawing = False
        FixedCols = 0
        RowCount = 40
        FixedRows = 1
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'Tahoma'
        Font.Style = []
        GridLineWidth = 1
        Options = [goFixedVertLine, goFixedHorzLine, goVertLine, goHorzLine, goRangeSelect, goDrawFocusSelected]
        ParentFont = False
        TabOrder = 0
        GridLineColor = clSilver
        ActiveCellShow = False
        ActiveCellFont.Charset = DEFAULT_CHARSET
        ActiveCellFont.Color = clWindowText
        ActiveCellFont.Height = -11
        ActiveCellFont.Name = 'MS Sans Serif'
        ActiveCellFont.Style = [fsBold]
        ActiveCellColor = clGray
        Bands.PrimaryColor = clInfoBk
        Bands.PrimaryLength = 1
        Bands.SecondaryColor = clWindow
        Bands.SecondaryLength = 1
        Bands.Print = False
        AutoNumAlign = False
        AutoSize = False
        VAlignment = vtaTop
        EnhTextSize = False
        EnhRowColMove = False
        SizeWithForm = False
        Multilinecells = False
        DragDropSettings.OleAcceptFiles = True
        DragDropSettings.OleAcceptText = True
        SortSettings.AutoColumnMerge = False
        SortSettings.Column = 0
        SortSettings.Show = False
        SortSettings.IndexShow = False
        SortSettings.IndexColor = clYellow
        SortSettings.Full = True
        SortSettings.SingleColumn = False
        SortSettings.IgnoreBlanks = False
        SortSettings.BlankPos = blFirst
        SortSettings.AutoFormat = True
        SortSettings.Direction = sdAscending
        SortSettings.FixedCols = False
        SortSettings.NormalCellsOnly = False
        SortSettings.Row = 0
        FloatingFooter.Color = clBtnFace
        FloatingFooter.Column = 0
        FloatingFooter.FooterStyle = fsFixedLastRow
        FloatingFooter.Visible = False
        ControlLook.Color = clBlack
        ControlLook.CheckSize = 15
        ControlLook.RadioSize = 10
        ControlLook.ControlStyle = csClassic
        ControlLook.FlatButton = False
        EnableBlink = False
        EnableHTML = True
        EnableWheel = True
        Flat = False
        HintColor = clInfoBk
        SelectionColor = clHighlight
        SelectionTextColor = clHighlightText
        SelectionRectangle = False
        SelectionResizer = False
        SelectionRTFKeep = False
        HintShowCells = False
        HintShowLargeText = False
        HintShowSizing = False
        PrintSettings.FooterSize = 0
        PrintSettings.HeaderSize = 0
        PrintSettings.Time = ppNone
        PrintSettings.Date = ppNone
        PrintSettings.DateFormat = 'dd/mm/yyyy'
        PrintSettings.PageNr = ppNone
        PrintSettings.Title = ppNone
        PrintSettings.Font.Charset = DEFAULT_CHARSET
        PrintSettings.Font.Color = clWindowText
        PrintSettings.Font.Height = -11
        PrintSettings.Font.Name = 'MS Sans Serif'
        PrintSettings.Font.Style = []
        PrintSettings.HeaderFont.Charset = DEFAULT_CHARSET
        PrintSettings.HeaderFont.Color = clWindowText
        PrintSettings.HeaderFont.Height = -11
        PrintSettings.HeaderFont.Name = 'MS Sans Serif'
        PrintSettings.HeaderFont.Style = []
        PrintSettings.FooterFont.Charset = DEFAULT_CHARSET
        PrintSettings.FooterFont.Color = clWindowText
        PrintSettings.FooterFont.Height = -11
        PrintSettings.FooterFont.Name = 'MS Sans Serif'
        PrintSettings.FooterFont.Style = []
        PrintSettings.Borders = pbNoborder
        PrintSettings.BorderStyle = psSolid
        PrintSettings.Centered = False
        PrintSettings.RepeatFixedRows = False
        PrintSettings.RepeatFixedCols = False
        PrintSettings.LeftSize = 0
        PrintSettings.RightSize = 0
        PrintSettings.ColumnSpacing = 0
        PrintSettings.RowSpacing = 0
        PrintSettings.TitleSpacing = 0
        PrintSettings.Orientation = poPortrait
        PrintSettings.PageNumberOffset = 0
        PrintSettings.MaxPagesOffset = 0
        PrintSettings.FixedWidth = 0
        PrintSettings.FixedHeight = 0
        PrintSettings.UseFixedHeight = False
        PrintSettings.UseFixedWidth = False
        PrintSettings.FitToPage = fpNever
        PrintSettings.PageNumSep = '/'
        PrintSettings.NoAutoSize = False
        PrintSettings.NoAutoSizeRow = False
        PrintSettings.PrintGraphics = False
        HTMLSettings.Width = 100
        HTMLSettings.XHTML = False
        Navigation.AdvanceDirection = adLeftRight
        Navigation.InsertPosition = pInsertBefore
        Navigation.HomeEndKey = heFirstLastColumn
        Navigation.TabToNextAtEnd = False
        Navigation.TabAdvanceDirection = adLeftRight
        ColumnSize.Location = clRegistry
        CellNode.Color = clSilver
        CellNode.NodeColor = clBlack
        CellNode.ShowTree = False
        MaxEditLength = 0
        IntelliPan = ipVertical
        URLColor = clBlue
        URLShow = False
        URLFull = False
        URLEdit = False
        ScrollType = ssNormal
        ScrollColor = clNone
        ScrollWidth = 17
        ScrollSynch = False
        ScrollProportional = False
        ScrollHints = shNone
        OemConvert = False
        FixedFooters = 0
        FixedRightCols = 0
        FixedColWidth = 75
        FixedRowHeight = 32
        FixedFont.Charset = DEFAULT_CHARSET
        FixedFont.Color = clWindowText
        FixedFont.Height = -13
        FixedFont.Name = #45208#45588#44256#46357
        FixedFont.Style = []
        FixedAsButtons = False
        FloatFormat = '%.2f'
        IntegralHeight = False
        WordWrap = False
        ColumnHeaders.Strings = (
          #54801#47141#48337#50896
          #48156#54665#45380#50900
          #48156#54665#48264#54840
          #51204#54364#52376#47532#49345#53468
          #51648#44553#50696#51221#44552#50529
          #48156#54665#51068#51088
          #48156#54665#45812#45817#51088
          #51204#54364#54869#51064#51068#51088
          #54869#51064#45812#45817#51088
          #51648#44553#54869#51064#51068
          #48708#44256)
        Lookup = False
        LookupCaseSensitive = False
        LookupHistory = False
        ShowSelection = False
        BackGround.Top = 0
        BackGround.Left = 0
        BackGround.Display = bdTile
        BackGround.Cells = bcNormal
        Filter = <>
        ColWidths = (
          75
          102
          77
          99
          86
          66
          76
          88
          76
          88
          64)
        RowHeights = (
          32
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25)
      end
    end
    object FlatButton2: TFlatButton
      Left = 1313
      Top = 63
      Width = 81
      Height = 23
      Caption = #51064#49604
      TabOrder = 2
    end
    object FlatPanel7: TFlatPanel
      Left = 921
      Top = 103
      Width = 479
      Height = 490
      ParentColor = True
      TabOrder = 7
      UseDockManager = True
      object AdvStringGrid1: TAdvStringGrid
        Left = 1
        Top = 1
        Width = 477
        Height = 488
        Cursor = crDefault
        Align = alClient
        ColCount = 7
        DefaultRowHeight = 25
        DefaultDrawing = False
        FixedCols = 0
        RowCount = 40
        FixedRows = 1
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'Tahoma'
        Font.Style = []
        GridLineWidth = 1
        Options = [goFixedVertLine, goFixedHorzLine, goVertLine, goHorzLine, goRangeSelect, goDrawFocusSelected]
        ParentFont = False
        TabOrder = 0
        GridLineColor = clSilver
        ActiveCellShow = False
        ActiveCellFont.Charset = DEFAULT_CHARSET
        ActiveCellFont.Color = clWindowText
        ActiveCellFont.Height = -11
        ActiveCellFont.Name = 'MS Sans Serif'
        ActiveCellFont.Style = [fsBold]
        ActiveCellColor = clGray
        Bands.PrimaryColor = clInfoBk
        Bands.PrimaryLength = 1
        Bands.SecondaryColor = clWindow
        Bands.SecondaryLength = 1
        Bands.Print = False
        AutoNumAlign = False
        AutoSize = False
        VAlignment = vtaTop
        EnhTextSize = False
        EnhRowColMove = False
        SizeWithForm = False
        Multilinecells = False
        DragDropSettings.OleAcceptFiles = True
        DragDropSettings.OleAcceptText = True
        SortSettings.AutoColumnMerge = False
        SortSettings.Column = 0
        SortSettings.Show = False
        SortSettings.IndexShow = False
        SortSettings.IndexColor = clYellow
        SortSettings.Full = True
        SortSettings.SingleColumn = False
        SortSettings.IgnoreBlanks = False
        SortSettings.BlankPos = blFirst
        SortSettings.AutoFormat = True
        SortSettings.Direction = sdAscending
        SortSettings.FixedCols = False
        SortSettings.NormalCellsOnly = False
        SortSettings.Row = 0
        FloatingFooter.Color = clBtnFace
        FloatingFooter.Column = 0
        FloatingFooter.FooterStyle = fsFixedLastRow
        FloatingFooter.Visible = False
        ControlLook.Color = clBlack
        ControlLook.CheckSize = 15
        ControlLook.RadioSize = 10
        ControlLook.ControlStyle = csClassic
        ControlLook.FlatButton = False
        EnableBlink = False
        EnableHTML = True
        EnableWheel = True
        Flat = False
        HintColor = clInfoBk
        SelectionColor = clHighlight
        SelectionTextColor = clHighlightText
        SelectionRectangle = False
        SelectionResizer = False
        SelectionRTFKeep = False
        HintShowCells = False
        HintShowLargeText = False
        HintShowSizing = False
        PrintSettings.FooterSize = 0
        PrintSettings.HeaderSize = 0
        PrintSettings.Time = ppNone
        PrintSettings.Date = ppNone
        PrintSettings.DateFormat = 'dd/mm/yyyy'
        PrintSettings.PageNr = ppNone
        PrintSettings.Title = ppNone
        PrintSettings.Font.Charset = DEFAULT_CHARSET
        PrintSettings.Font.Color = clWindowText
        PrintSettings.Font.Height = -11
        PrintSettings.Font.Name = 'MS Sans Serif'
        PrintSettings.Font.Style = []
        PrintSettings.HeaderFont.Charset = DEFAULT_CHARSET
        PrintSettings.HeaderFont.Color = clWindowText
        PrintSettings.HeaderFont.Height = -11
        PrintSettings.HeaderFont.Name = 'MS Sans Serif'
        PrintSettings.HeaderFont.Style = []
        PrintSettings.FooterFont.Charset = DEFAULT_CHARSET
        PrintSettings.FooterFont.Color = clWindowText
        PrintSettings.FooterFont.Height = -11
        PrintSettings.FooterFont.Name = 'MS Sans Serif'
        PrintSettings.FooterFont.Style = []
        PrintSettings.Borders = pbNoborder
        PrintSettings.BorderStyle = psSolid
        PrintSettings.Centered = False
        PrintSettings.RepeatFixedRows = False
        PrintSettings.RepeatFixedCols = False
        PrintSettings.LeftSize = 0
        PrintSettings.RightSize = 0
        PrintSettings.ColumnSpacing = 0
        PrintSettings.RowSpacing = 0
        PrintSettings.TitleSpacing = 0
        PrintSettings.Orientation = poPortrait
        PrintSettings.PageNumberOffset = 0
        PrintSettings.MaxPagesOffset = 0
        PrintSettings.FixedWidth = 0
        PrintSettings.FixedHeight = 0
        PrintSettings.UseFixedHeight = False
        PrintSettings.UseFixedWidth = False
        PrintSettings.FitToPage = fpNever
        PrintSettings.PageNumSep = '/'
        PrintSettings.NoAutoSize = False
        PrintSettings.NoAutoSizeRow = False
        PrintSettings.PrintGraphics = False
        HTMLSettings.Width = 100
        HTMLSettings.XHTML = False
        Navigation.AdvanceDirection = adLeftRight
        Navigation.InsertPosition = pInsertBefore
        Navigation.HomeEndKey = heFirstLastColumn
        Navigation.TabToNextAtEnd = False
        Navigation.TabAdvanceDirection = adLeftRight
        ColumnSize.Location = clRegistry
        CellNode.Color = clSilver
        CellNode.NodeColor = clBlack
        CellNode.ShowTree = False
        MaxEditLength = 0
        IntelliPan = ipVertical
        URLColor = clBlue
        URLShow = False
        URLFull = False
        URLEdit = False
        ScrollType = ssNormal
        ScrollColor = clNone
        ScrollWidth = 17
        ScrollSynch = False
        ScrollProportional = False
        ScrollHints = shNone
        OemConvert = False
        FixedFooters = 0
        FixedRightCols = 0
        FixedColWidth = 39
        FixedRowHeight = 32
        FixedFont.Charset = DEFAULT_CHARSET
        FixedFont.Color = clWindowText
        FixedFont.Height = -13
        FixedFont.Name = #45208#45588#44256#46357
        FixedFont.Style = []
        FixedAsButtons = False
        FloatFormat = '%.2f'
        IntegralHeight = False
        WordWrap = False
        ColumnHeaders.Strings = (
          ''
          #44144#47000#52376#47749
          #51648#44553#44552#50529#44228
          #44148#49688
          #51217#49688#48264#54840
          #44160#51652#51088#47749
          #44160#51652#51068#51088)
        Lookup = False
        LookupCaseSensitive = False
        LookupHistory = False
        ShowSelection = False
        BackGround.Top = 0
        BackGround.Left = 0
        BackGround.Display = bdTile
        BackGround.Cells = bcNormal
        Filter = <>
        ColWidths = (
          39
          88
          77
          38
          82
          66
          76)
        RowHeights = (
          32
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25)
      end
    end
    object FlatPanel10: TFlatPanel
      Left = 1
      Top = 593
      Width = 1399
      Height = 135
      Caption = #47532
      ParentColor = True
      TabOrder = 8
      UseDockManager = True
      object Label19: TLabel
        Left = 6
        Top = 7
        Width = 75
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #54801#47141#48337#50896
        Layout = tlCenter
      end
      object Label20: TLabel
        Left = 6
        Top = 32
        Width = 75
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #51204#54364#48156#54665#51068#51088
        Layout = tlCenter
      end
      object Label24: TLabel
        Left = 6
        Top = 57
        Width = 75
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #51204#54364#54869#51064#51068#51088
        Layout = tlCenter
      end
      object Label1: TLabel
        Left = 272
        Top = 7
        Width = 75
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #48156#54665#45380#50900
        Layout = tlCenter
      end
      object Label2: TLabel
        Left = 272
        Top = 32
        Width = 75
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #48156#54665#45812#45817#51088
        Layout = tlCenter
      end
      object Label3: TLabel
        Left = 272
        Top = 57
        Width = 75
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #54869#51064#45812#45817#51088
        Layout = tlCenter
      end
      object Label4: TLabel
        Left = 538
        Top = 7
        Width = 75
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #52376#47532#49345#53468
        Layout = tlCenter
      end
      object Label5: TLabel
        Left = 538
        Top = 32
        Width = 75
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #51648#44553#50696#51221#44552#50529
        Layout = tlCenter
      end
      object Label6: TLabel
        Left = 538
        Top = 57
        Width = 75
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #51648#44553#54869#51064#51068
        Layout = tlCenter
      end
      object Label7: TLabel
        Left = 804
        Top = 7
        Width = 75
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #50696#44552#51452
        Layout = tlCenter
      end
      object Label8: TLabel
        Left = 804
        Top = 32
        Width = 75
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #51008#54665
        Layout = tlCenter
      end
      object Label9: TLabel
        Left = 804
        Top = 57
        Width = 75
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #44228#51340#48264#54840
        Layout = tlCenter
      end
      object Label10: TLabel
        Left = 6
        Top = 87
        Width = 75
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #52376#47532#50976#54805
        Layout = tlCenter
      end
      object Label11: TLabel
        Left = 272
        Top = 87
        Width = 75
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #48708#44256
        Layout = tlCenter
      end
      object FlatEdit8: TFlatEdit
        Left = 88
        Top = 7
        Width = 169
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 0
      end
      object FlatEdit9: TFlatEdit
        Left = 88
        Top = 32
        Width = 169
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 1
      end
      object FlatEdit10: TFlatEdit
        Left = 88
        Top = 57
        Width = 169
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 2
      end
      object FlatEdit2: TFlatEdit
        Left = 354
        Top = 7
        Width = 127
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 3
      end
      object FlatEdit3: TFlatEdit
        Left = 354
        Top = 32
        Width = 169
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 4
      end
      object FlatEdit4: TFlatEdit
        Left = 354
        Top = 57
        Width = 169
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 5
      end
      object FlatEdit6: TFlatEdit
        Left = 482
        Top = 7
        Width = 41
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 6
      end
      object FlatEdit7: TFlatEdit
        Left = 620
        Top = 7
        Width = 169
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 7
      end
      object FlatEdit11: TFlatEdit
        Left = 620
        Top = 32
        Width = 169
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 8
      end
      object FlatEdit12: TFlatEdit
        Left = 620
        Top = 57
        Width = 169
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 9
      end
      object FlatEdit13: TFlatEdit
        Left = 886
        Top = 57
        Width = 169
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 10
      end
      object FlatEdit14: TFlatEdit
        Left = 886
        Top = 32
        Width = 169
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 11
      end
      object FlatEdit15: TFlatEdit
        Left = 886
        Top = 7
        Width = 169
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 12
      end
      object FlatComboBox5: TFlatComboBox
        Left = 88
        Top = 87
        Width = 168
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 13
        ItemIndex = -1
      end
      object FlatEdit16: TFlatEdit
        Left = 354
        Top = 87
        Width = 701
        Height = 42
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 14
      end
    end
    object FlatButton3: TFlatButton
      Left = 1313
      Top = 86
      Width = 81
      Height = 23
      Caption = #51200#51109
      TabOrder = 9
    end
  end
end
