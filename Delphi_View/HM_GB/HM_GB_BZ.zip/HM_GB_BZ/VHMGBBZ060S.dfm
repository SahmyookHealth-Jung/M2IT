object Form49: TForm49
  Left = -8
  Top = -8
  Width = 1552
  Height = 832
  Caption = #51648#49324#47588#52636' '#51217#49688#44288#47532' [VHMGBBZ060S]'
  Color = clWhite
  Font.Charset = ANSI_CHARSET
  Font.Color = clWindowText
  Font.Height = -13
  Font.Name = #45208#45588#44256#46357
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 15
  object FlatPanel1: TFlatPanel
    Left = 16
    Top = 7
    Width = 1681
    Height = 882
    ParentColor = True
    TabOrder = 0
    UseDockManager = True
    object FlatPanel9: TFlatPanel
      Left = 432
      Top = 71
      Width = 1248
      Height = 33
      ParentColor = True
      TabOrder = 7
      UseDockManager = True
      object FlatLabel1: TFlatLabel
        Left = 3
        Top = 4
        Width = 67
        Height = 25
        Alignment = taRightJustify
        TextBorder = 2
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #49345#49464#51221#48372
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = True
        ShowEssential = False
      end
    end
    object FlatPanel8: TFlatPanel
      Left = 432
      Top = 104
      Width = 1248
      Height = 246
      ParentColor = True
      TabOrder = 6
      UseDockManager = True
      object FlaTFlatPanel72: TLabel
        Left = 4
        Top = 8
        Width = 60
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #54924#50896#48264#54840
        Layout = tlCenter
      end
      object Label1: TLabel
        Left = 4
        Top = 32
        Width = 60
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #51452#48124#48264#54840
        Layout = tlCenter
      end
      object Label2: TLabel
        Left = 4
        Top = 56
        Width = 60
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #54648#46300#54256
        Layout = tlCenter
      end
      object FlaTFlatPanel21: TLabel
        Left = 430
        Top = 79
        Width = 36
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #44144#47000#52376
        Layout = tlCenter
      end
      object FlaTFlatPanel30: TLabel
        Left = 417
        Top = 30
        Width = 48
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #50696#50557#51068#49884
        Layout = tlCenter
      end
      object Label3: TLabel
        Left = 194
        Top = 8
        Width = 60
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #51217#49688#44396#48516
        Layout = tlCenter
      end
      object Label4: TLabel
        Left = 194
        Top = 32
        Width = 60
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #49457#47749
        Layout = tlCenter
      end
      object Label5: TLabel
        Left = 4
        Top = 80
        Width = 60
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #51068#48152#51204#54868
        Layout = tlCenter
      end
      object Label6: TLabel
        Left = 194
        Top = 56
        Width = 60
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #49457#47749'('#50689#47928')'
        Layout = tlCenter
      end
      object Label7: TLabel
        Left = 418
        Top = 7
        Width = 48
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #45236#49884#44221
        Layout = tlCenter
      end
      object Label8: TLabel
        Left = 417
        Top = 54
        Width = 48
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #51217#49688#51068#49884
        Layout = tlCenter
      end
      object Label9: TLabel
        Left = 4
        Top = 104
        Width = 60
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #48512#49436#47749
        Layout = tlCenter
      end
      object Label10: TLabel
        Left = 4
        Top = 128
        Width = 60
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #49324#50896#48264#54840
        Layout = tlCenter
      end
      object Label11: TLabel
        Left = 193
        Top = 80
        Width = 60
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #51217#49688#52376
        Layout = tlCenter
      end
      object Label12: TLabel
        Left = 193
        Top = 104
        Width = 60
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #51649#44553
        Layout = tlCenter
      end
      object Label13: TLabel
        Left = 193
        Top = 128
        Width = 60
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #48176#50864#51088
        Layout = tlCenter
      end
      object Label14: TLabel
        Left = 5
        Top = 152
        Width = 60
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #51649#51333#44396#48516
        Layout = tlCenter
      end
      object Label15: TLabel
        Left = 194
        Top = 152
        Width = 60
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = 'VIP'
        Layout = tlCenter
      end
      object Label16: TLabel
        Left = 416
        Top = 103
        Width = 50
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #50689#50629#49324#50896
        Layout = tlCenter
      end
      object Label17: TLabel
        Left = 693
        Top = 103
        Width = 60
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #51089#50629#44277#51221#47749
        Layout = tlCenter
      end
      object Label18: TLabel
        Left = 400
        Top = 126
        Width = 65
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #53945#44160#44396#48516
        Layout = tlCenter
      end
      object Label24: TLabel
        Left = 400
        Top = 150
        Width = 65
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #51077#49324#51068#51088
        Layout = tlCenter
      end
      object Label25: TLabel
        Left = 688
        Top = 126
        Width = 65
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #52712#44553#47932#51656
        Layout = tlCenter
      end
      object Label26: TLabel
        Left = 688
        Top = 150
        Width = 65
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #51204#51077#51068#51088
        Layout = tlCenter
      end
      object Label27: TLabel
        Left = 416
        Top = 175
        Width = 50
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #51648#48169#48337#50896
        Layout = tlCenter
      end
      object Label28: TLabel
        Left = 688
        Top = 174
        Width = 65
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #48337#50896#44160#51652#51068
        Layout = tlCenter
      end
      object Label29: TLabel
        Left = 5
        Top = 176
        Width = 60
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #51452#49548
        Layout = tlCenter
      end
      object Label30: TLabel
        Left = 403
        Top = 199
        Width = 61
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = 'E-Mail'
        Layout = tlCenter
      end
      object FlatEdit1: TFlatEdit
        Left = 469
        Top = 79
        Width = 102
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 0
      end
      object FlatSpinEditInteger1: TFlatSpinEditInteger
        Left = 570
        Top = 79
        Width = 64
        Height = 23
        ColorFlat = clWhite
        AutoSize = False
        MaxValue = 0
        MinValue = 0
        TabOrder = 1
        Value = 2026
      end
      object FlatComboBox7: TFlatComboBox
        Left = 633
        Top = 79
        Width = 69
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 2
        ItemIndex = -1
      end
      object FlatComboBox8: TFlatComboBox
        Left = 701
        Top = 79
        Width = 104
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 3
        ItemIndex = -1
      end
      object FlatComboBox10: TFlatComboBox
        Left = 469
        Top = 31
        Width = 121
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 4
        ItemIndex = -1
      end
      object FlatEdit2: TFlatEdit
        Left = 257
        Top = 32
        Width = 121
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 5
      end
      object FlatEdit3: TFlatEdit
        Left = 257
        Top = 56
        Width = 121
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 6
      end
      object FlatEdit4: TFlatEdit
        Left = 68
        Top = 8
        Width = 121
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 7
      end
      object FlatEdit6: TFlatEdit
        Left = 68
        Top = 32
        Width = 121
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 8
      end
      object FlatEdit7: TFlatEdit
        Left = 68
        Top = 56
        Width = 121
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 9
      end
      object FlatEdit14: TFlatEdit
        Left = 68
        Top = 80
        Width = 121
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 10
      end
      object FlatSpinEditInteger2: TFlatSpinEditInteger
        Left = 597
        Top = 30
        Width = 46
        Height = 23
        ColorFlat = clWhite
        AutoSize = False
        MaxValue = 0
        MinValue = 0
        TabOrder = 11
        Value = 12
      end
      object FlatSpinEditInteger3: TFlatSpinEditInteger
        Left = 647
        Top = 30
        Width = 46
        Height = 23
        ColorFlat = clWhite
        AutoSize = False
        MaxValue = 0
        MinValue = 0
        TabOrder = 12
        Value = 30
      end
      object pn_Panel011: TFlatPanel
        Left = 469
        Top = 7
        Width = 137
        Height = 23
        ParentColor = True
        TabOrder = 13
        UseDockManager = True
        object FlatRadioButton16: TFlatRadioButton
          Left = 18
          Top = 2
          Width = 50
          Height = 17
          Caption = 'UGI'
          TabOrder = 0
        end
        object FlatRadioButton17: TFlatRadioButton
          Left = 71
          Top = 2
          Width = 50
          Height = 17
          Caption = 'Endo'
          TabOrder = 1
        end
      end
      object FlatComboBox3: TFlatComboBox
        Left = 469
        Top = 55
        Width = 121
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 14
        ItemIndex = -1
      end
      object FlatSpinEditInteger4: TFlatSpinEditInteger
        Left = 597
        Top = 54
        Width = 46
        Height = 23
        ColorFlat = clWhite
        AutoSize = False
        MaxValue = 0
        MinValue = 0
        TabOrder = 15
        Value = 12
      end
      object FlatSpinEditInteger5: TFlatSpinEditInteger
        Left = 647
        Top = 54
        Width = 46
        Height = 23
        ColorFlat = clWhite
        AutoSize = False
        MaxValue = 0
        MinValue = 0
        TabOrder = 16
        Value = 30
      end
      object FlatComboBox12: TFlatComboBox
        Left = 68
        Top = 176
        Width = 61
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 17
        ItemIndex = -1
      end
      object FlatEdit19: TFlatEdit
        Left = 68
        Top = 200
        Width = 310
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 18
      end
      object FlatEdit17: TFlatEdit
        Left = 68
        Top = 104
        Width = 121
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 19
      end
      object FlatEdit18: TFlatEdit
        Left = 68
        Top = 128
        Width = 121
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 20
      end
      object FlatEdit21: TFlatEdit
        Left = 257
        Top = 104
        Width = 121
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 21
      end
      object FlatEdit22: TFlatEdit
        Left = 257
        Top = 128
        Width = 121
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 22
      end
      object FlatComboBox4: TFlatComboBox
        Left = 257
        Top = 8
        Width = 121
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 23
        ItemIndex = -1
      end
      object FlatComboBox5: TFlatComboBox
        Left = 257
        Top = 80
        Width = 121
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 24
        ItemIndex = -1
      end
      object FlatGroupBox3: TFlatGroupBox
        Left = 895
        Top = 8
        Width = 330
        Height = 120
        Font.Charset = ANSI_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        ParentFont = False
        Color = clWhite
        ParentColor = False
        TabOrder = 25
        object FlatCheckBox15: TFlatCheckBox
          Left = 7
          Top = 6
          Width = 128
          Height = 22
          Caption = #54869#51064
          TabOrder = 0
          TabStop = True
        end
        object FlatCheckBox16: TFlatCheckBox
          Left = 7
          Top = 27
          Width = 128
          Height = 22
          Caption = #51068#51088#48320#44221
          TabOrder = 1
          TabStop = True
        end
        object FlatCheckBox17: TFlatCheckBox
          Left = 7
          Top = 48
          Width = 128
          Height = 22
          Caption = #51452#48124#48264#54840#48120#51228#44277#51088
          TabOrder = 2
          TabStop = True
        end
        object FlatCheckBox18: TFlatCheckBox
          Left = 7
          Top = 91
          Width = 128
          Height = 22
          Caption = #49688#47732#50557#51228#48708
          TabOrder = 3
          TabStop = True
        end
        object FlatCheckBox19: TFlatCheckBox
          Left = 7
          Top = 69
          Width = 128
          Height = 22
          Caption = #50948#44160#49324
          TabOrder = 4
          TabStop = True
        end
        object FlatCheckBox20: TFlatCheckBox
          Left = 179
          Top = 6
          Width = 128
          Height = 22
          Caption = #51068#48152'/'#49373#50528#52397#44396#50668#48512
          TabOrder = 5
          TabStop = True
        end
        object FlatCheckBox21: TFlatCheckBox
          Left = 179
          Top = 27
          Width = 128
          Height = 22
          Caption = #50516#52397#44396' '#50668#48512
          TabOrder = 6
          TabStop = True
        end
        object FlatCheckBox22: TFlatCheckBox
          Left = 179
          Top = 48
          Width = 128
          Height = 22
          Caption = #50672#49549
          TabOrder = 7
          TabStop = True
        end
        object FlatCheckBox24: TFlatCheckBox
          Left = 179
          Top = 69
          Width = 128
          Height = 22
          Caption = #45824#51109#45236#49884#44221
          TabOrder = 8
          TabStop = True
        end
      end
      object FlatComboBox6: TFlatComboBox
        Left = 68
        Top = 152
        Width = 121
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 26
        ItemIndex = -1
      end
      object FlatComboBox11: TFlatComboBox
        Left = 257
        Top = 152
        Width = 121
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 27
        ItemIndex = -1
      end
      object FlatEdit15: TFlatEdit
        Left = 469
        Top = 103
        Width = 76
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 28
      end
      object FlatComboBox13: TFlatComboBox
        Left = 547
        Top = 103
        Width = 69
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 29
        ItemIndex = -1
      end
      object FlatEdit20: TFlatEdit
        Left = 757
        Top = 103
        Width = 121
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 30
      end
      object FlatComboBox14: TFlatComboBox
        Left = 469
        Top = 127
        Width = 121
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 31
        ItemIndex = -1
      end
      object FlatComboBox15: TFlatComboBox
        Left = 469
        Top = 151
        Width = 121
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 32
        ItemIndex = -1
      end
      object FlatComboBox17: TFlatComboBox
        Left = 757
        Top = 127
        Width = 121
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 33
        ItemIndex = -1
      end
      object FlatComboBox18: TFlatComboBox
        Left = 757
        Top = 151
        Width = 121
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 34
        ItemIndex = -1
      end
      object FlatEdit23: TFlatEdit
        Left = 469
        Top = 175
        Width = 76
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 35
      end
      object FlatComboBox19: TFlatComboBox
        Left = 547
        Top = 175
        Width = 134
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 36
        ItemIndex = -1
      end
      object FlatComboBox20: TFlatComboBox
        Left = 757
        Top = 175
        Width = 121
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 37
        ItemIndex = -1
      end
      object FlatComboBox21: TFlatComboBox
        Left = 132
        Top = 176
        Width = 246
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 38
        ItemIndex = -1
      end
      object FlatComboBox23: TFlatComboBox
        Left = 610
        Top = 199
        Width = 35
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 39
        Text = '@'
        ItemIndex = -1
      end
      object FlatEdit16: TFlatEdit
        Left = 469
        Top = 199
        Width = 140
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 40
      end
      object FlatEdit24: TFlatEdit
        Left = 647
        Top = 199
        Width = 108
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 41
      end
      object FlatComboBox22: TFlatComboBox
        Left = 757
        Top = 199
        Width = 121
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 42
        ItemIndex = -1
      end
    end
    object FlatPanel5: TFlatPanel
      Left = 1
      Top = 38
      Width = 1679
      Height = 33
      ParentColor = True
      TabOrder = 3
      UseDockManager = True
    end
    object FlatPanel3: TFlatPanel
      Left = 1
      Top = 1
      Width = 1679
      Height = 37
      ParentColor = True
      TabOrder = 0
      UseDockManager = True
      object FlatLabel2: TFlatLabel
        Left = 6
        Top = 4
        Width = 65
        Height = 25
        Alignment = taRightJustify
        TextBorder = 0
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #50696#50557'/'#51217#49688
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = False
        ShowEssential = True
      end
      object FlatLabel8: TFlatLabel
        Left = 398
        Top = 4
        Width = 65
        Height = 25
        Alignment = taRightJustify
        TextBorder = 0
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #51217#49688#51068#51088
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = False
        ShowEssential = False
      end
      object FlatLabel3: TFlatLabel
        Left = 195
        Top = 4
        Width = 65
        Height = 25
        Alignment = taRightJustify
        TextBorder = 0
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #51217#49688#44396#48516
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = False
        ShowEssential = True
      end
      object FlatLabel4: TFlatLabel
        Left = 595
        Top = 4
        Width = 65
        Height = 25
        Alignment = taRightJustify
        TextBorder = 0
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #49373#45380#50900#51068
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = False
        ShowEssential = False
      end
      object FlatLabel9: TFlatLabel
        Left = 787
        Top = 4
        Width = 65
        Height = 25
        Alignment = taRightJustify
        TextBorder = 0
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #44160#49353#51312#44148
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = False
        ShowEssential = False
      end
      object FlatButton1: TFlatButton
        Left = 1600
        Top = 6
        Width = 72
        Height = 23
        Color = clSilver
        Caption = #51312#54924
        ParentColor = False
        TabOrder = 0
      end
      object FlatComboBox9: TFlatComboBox
        Left = 75
        Top = 6
        Width = 113
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 1
        ItemIndex = -1
      end
      object FlatComboBox16: TFlatComboBox
        Left = 467
        Top = 6
        Width = 113
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 2
        ItemIndex = -1
      end
      object FlatComboBox1: TFlatComboBox
        Left = 264
        Top = 6
        Width = 113
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 3
        ItemIndex = -1
      end
      object FlatEdit5: TFlatEdit
        Left = 664
        Top = 6
        Width = 113
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 4
      end
      object FlatEdit8: TFlatEdit
        Left = 858
        Top = 6
        Width = 121
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 5
      end
    end
    object FlatComboBox2: TFlatComboBox
      Left = 1601
      Top = 43
      Width = 72
      Height = 23
      Color = clWindow
      ItemHeight = 15
      TabOrder = 1
      Text = '  Action'
      ItemIndex = -1
    end
    object FlatButton2: TFlatButton
      Left = 1594
      Top = 66
      Width = 81
      Height = 23
      Caption = #51200#51109
      TabOrder = 2
    end
    object FlatButton3: TFlatButton
      Left = 1594
      Top = 89
      Width = 81
      Height = 23
      Caption = #52628#44032
      TabOrder = 4
    end
    object FlatButton4: TFlatButton
      Left = 1594
      Top = 112
      Width = 81
      Height = 23
      Caption = #49325#51228
      TabOrder = 5
    end
    object FlatPanel4: TFlatPanel
      Left = 433
      Top = 529
      Width = 1247
      Height = 33
      ParentColor = True
      TabOrder = 8
      UseDockManager = True
      object FlatLabel6: TFlatLabel
        Left = 3
        Top = 4
        Width = 66
        Height = 25
        Alignment = taRightJustify
        TextBorder = 2
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #44228#50557#51221#48372
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = True
        ShowEssential = False
      end
    end
    object FlatGroupBox4: TFlatGroupBox
      Left = 434
      Top = 386
      Width = 534
      Height = 143
      TabOrder = 9
      object FlatMemo1: TFlatMemo
        Left = 4
        Top = 8
        Width = 523
        Height = 127
        ColorFlat = clWhite
        TabOrder = 0
      end
    end
    object FlatPanel7: TFlatPanel
      Left = 433
      Top = 350
      Width = 536
      Height = 35
      ParentColor = True
      TabOrder = 10
      UseDockManager = True
      object FlatLabel7: TFlatLabel
        Left = 4
        Top = 4
        Width = 94
        Height = 25
        Alignment = taRightJustify
        TextBorder = 2
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #52264#53944#46321#47197#49324#54637
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = True
        ShowEssential = False
      end
    end
    object FlatPanel2: TFlatPanel
      Left = 1
      Top = 71
      Width = 432
      Height = 33
      ParentColor = True
      TabOrder = 11
      UseDockManager = True
      object FlatLabel5: TFlatLabel
        Left = 3
        Top = 4
        Width = 67
        Height = 25
        Alignment = taRightJustify
        TextBorder = 2
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #51217#49688' List'
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = True
        ShowEssential = False
      end
    end
    object FlatPanel10: TFlatPanel
      Left = 1
      Top = 104
      Width = 432
      Height = 721
      ParentColor = True
      TabOrder = 12
      UseDockManager = True
      object AdvStringGrid2: TAdvStringGrid
        Left = 1
        Top = 1
        Width = 430
        Height = 719
        Cursor = crDefault
        Align = alClient
        ColCount = 9
        DefaultRowHeight = 25
        DefaultDrawing = False
        FixedCols = 0
        RowCount = 40
        FixedRows = 1
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'Tahoma'
        Font.Style = []
        GridLineWidth = 1
        Options = [goFixedVertLine, goFixedHorzLine, goVertLine, goHorzLine, goRangeSelect, goDrawFocusSelected]
        ParentFont = False
        TabOrder = 0
        GridLineColor = clSilver
        ActiveCellShow = False
        ActiveCellFont.Charset = DEFAULT_CHARSET
        ActiveCellFont.Color = clWindowText
        ActiveCellFont.Height = -11
        ActiveCellFont.Name = 'MS Sans Serif'
        ActiveCellFont.Style = [fsBold]
        ActiveCellColor = clGray
        Bands.PrimaryColor = clInfoBk
        Bands.PrimaryLength = 1
        Bands.SecondaryColor = clWindow
        Bands.SecondaryLength = 1
        Bands.Print = False
        AutoNumAlign = False
        AutoSize = False
        VAlignment = vtaTop
        EnhTextSize = False
        EnhRowColMove = False
        SizeWithForm = False
        Multilinecells = False
        DragDropSettings.OleAcceptFiles = True
        DragDropSettings.OleAcceptText = True
        SortSettings.AutoColumnMerge = False
        SortSettings.Column = 0
        SortSettings.Show = False
        SortSettings.IndexShow = False
        SortSettings.IndexColor = clYellow
        SortSettings.Full = True
        SortSettings.SingleColumn = False
        SortSettings.IgnoreBlanks = False
        SortSettings.BlankPos = blFirst
        SortSettings.AutoFormat = True
        SortSettings.Direction = sdAscending
        SortSettings.FixedCols = False
        SortSettings.NormalCellsOnly = False
        SortSettings.Row = 0
        FloatingFooter.Color = clBtnFace
        FloatingFooter.Column = 0
        FloatingFooter.FooterStyle = fsFixedLastRow
        FloatingFooter.Visible = False
        ControlLook.Color = clBlack
        ControlLook.CheckSize = 15
        ControlLook.RadioSize = 10
        ControlLook.ControlStyle = csClassic
        ControlLook.FlatButton = False
        EnableBlink = False
        EnableHTML = True
        EnableWheel = True
        Flat = False
        HintColor = clInfoBk
        SelectionColor = clHighlight
        SelectionTextColor = clHighlightText
        SelectionRectangle = False
        SelectionResizer = False
        SelectionRTFKeep = False
        HintShowCells = False
        HintShowLargeText = False
        HintShowSizing = False
        PrintSettings.FooterSize = 0
        PrintSettings.HeaderSize = 0
        PrintSettings.Time = ppNone
        PrintSettings.Date = ppNone
        PrintSettings.DateFormat = 'dd/mm/yyyy'
        PrintSettings.PageNr = ppNone
        PrintSettings.Title = ppNone
        PrintSettings.Font.Charset = DEFAULT_CHARSET
        PrintSettings.Font.Color = clWindowText
        PrintSettings.Font.Height = -11
        PrintSettings.Font.Name = 'MS Sans Serif'
        PrintSettings.Font.Style = []
        PrintSettings.HeaderFont.Charset = DEFAULT_CHARSET
        PrintSettings.HeaderFont.Color = clWindowText
        PrintSettings.HeaderFont.Height = -11
        PrintSettings.HeaderFont.Name = 'MS Sans Serif'
        PrintSettings.HeaderFont.Style = []
        PrintSettings.FooterFont.Charset = DEFAULT_CHARSET
        PrintSettings.FooterFont.Color = clWindowText
        PrintSettings.FooterFont.Height = -11
        PrintSettings.FooterFont.Name = 'MS Sans Serif'
        PrintSettings.FooterFont.Style = []
        PrintSettings.Borders = pbNoborder
        PrintSettings.BorderStyle = psSolid
        PrintSettings.Centered = False
        PrintSettings.RepeatFixedRows = False
        PrintSettings.RepeatFixedCols = False
        PrintSettings.LeftSize = 0
        PrintSettings.RightSize = 0
        PrintSettings.ColumnSpacing = 0
        PrintSettings.RowSpacing = 0
        PrintSettings.TitleSpacing = 0
        PrintSettings.Orientation = poPortrait
        PrintSettings.PageNumberOffset = 0
        PrintSettings.MaxPagesOffset = 0
        PrintSettings.FixedWidth = 0
        PrintSettings.FixedHeight = 0
        PrintSettings.UseFixedHeight = False
        PrintSettings.UseFixedWidth = False
        PrintSettings.FitToPage = fpNever
        PrintSettings.PageNumSep = '/'
        PrintSettings.NoAutoSize = False
        PrintSettings.NoAutoSizeRow = False
        PrintSettings.PrintGraphics = False
        HTMLSettings.Width = 100
        HTMLSettings.XHTML = False
        Navigation.AdvanceDirection = adLeftRight
        Navigation.InsertPosition = pInsertBefore
        Navigation.HomeEndKey = heFirstLastColumn
        Navigation.TabToNextAtEnd = False
        Navigation.TabAdvanceDirection = adLeftRight
        ColumnSize.Location = clRegistry
        CellNode.Color = clSilver
        CellNode.NodeColor = clBlack
        CellNode.ShowTree = False
        MaxEditLength = 0
        IntelliPan = ipVertical
        URLColor = clBlue
        URLShow = False
        URLFull = False
        URLEdit = False
        ScrollType = ssNormal
        ScrollColor = clNone
        ScrollWidth = 17
        ScrollSynch = False
        ScrollProportional = False
        ScrollHints = shNone
        OemConvert = False
        FixedFooters = 0
        FixedRightCols = 0
        FixedColWidth = 35
        FixedRowHeight = 32
        FixedFont.Charset = DEFAULT_CHARSET
        FixedFont.Color = clWindowText
        FixedFont.Height = -13
        FixedFont.Name = #45208#45588#44256#46357
        FixedFont.Style = []
        FixedAsButtons = False
        FloatFormat = '%.2f'
        IntegralHeight = False
        WordWrap = False
        ColumnHeaders.Strings = (
          ''
          #51088#44201
          ''
          #51217#49688#48264#54840
          ''
          #49457#47749
          #49373#45380#50900#51068
          ''
          #51217#49688#52376)
        Lookup = False
        LookupCaseSensitive = False
        LookupHistory = False
        ShowSelection = False
        BackGround.Top = 0
        BackGround.Left = 0
        BackGround.Display = bdTile
        BackGround.Cells = bcNormal
        Filter = <>
        ColWidths = (
          35
          34
          25
          71
          17
          64
          64
          29
          72)
        RowHeights = (
          32
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25)
      end
    end
    object FlatPanel6: TFlatPanel
      Left = 969
      Top = 350
      Width = 711
      Height = 35
      ParentColor = True
      TabOrder = 13
      UseDockManager = True
      object FlatLabel10: TFlatLabel
        Left = 3
        Top = 4
        Height = 25
        Alignment = taRightJustify
        TextBorder = 2
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #51204#45804' '#49324#54637
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = True
        ShowEssential = False
      end
    end
    object FlatGroupBox5: TFlatGroupBox
      Left = 970
      Top = 386
      Width = 710
      Height = 143
      TabOrder = 14
      object FlatMemo2: TFlatMemo
        Left = 4
        Top = 8
        Width = 701
        Height = 129
        ColorFlat = clWhite
        TabOrder = 0
      end
    end
    object AdvStringGrid3: TAdvStringGrid
      Left = 432
      Top = 560
      Width = 1248
      Height = 249
      Cursor = crDefault
      ColCount = 9
      DefaultColWidth = 100
      DefaultRowHeight = 25
      DefaultDrawing = False
      FixedCols = 0
      RowCount = 40
      FixedRows = 1
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      GridLineWidth = 1
      Options = [goFixedVertLine, goFixedHorzLine, goVertLine, goHorzLine, goRangeSelect, goDrawFocusSelected]
      ParentFont = False
      TabOrder = 15
      GridLineColor = clSilver
      ActiveCellShow = False
      ActiveCellFont.Charset = DEFAULT_CHARSET
      ActiveCellFont.Color = clWindowText
      ActiveCellFont.Height = -11
      ActiveCellFont.Name = 'MS Sans Serif'
      ActiveCellFont.Style = [fsBold]
      ActiveCellColor = clGray
      Bands.PrimaryColor = clInfoBk
      Bands.PrimaryLength = 1
      Bands.SecondaryColor = clWindow
      Bands.SecondaryLength = 1
      Bands.Print = False
      AutoNumAlign = False
      AutoSize = False
      VAlignment = vtaTop
      EnhTextSize = False
      EnhRowColMove = False
      SizeWithForm = False
      Multilinecells = False
      DragDropSettings.OleAcceptFiles = True
      DragDropSettings.OleAcceptText = True
      SortSettings.AutoColumnMerge = False
      SortSettings.Column = 0
      SortSettings.Show = False
      SortSettings.IndexShow = False
      SortSettings.IndexColor = clYellow
      SortSettings.Full = True
      SortSettings.SingleColumn = False
      SortSettings.IgnoreBlanks = False
      SortSettings.BlankPos = blFirst
      SortSettings.AutoFormat = True
      SortSettings.Direction = sdAscending
      SortSettings.FixedCols = False
      SortSettings.NormalCellsOnly = False
      SortSettings.Row = 0
      FloatingFooter.Color = clBtnFace
      FloatingFooter.Column = 0
      FloatingFooter.FooterStyle = fsFixedLastRow
      FloatingFooter.Visible = False
      ControlLook.Color = clBlack
      ControlLook.CheckSize = 15
      ControlLook.RadioSize = 10
      ControlLook.ControlStyle = csClassic
      ControlLook.FlatButton = False
      EnableBlink = False
      EnableHTML = True
      EnableWheel = True
      Flat = False
      HintColor = clInfoBk
      SelectionColor = clHighlight
      SelectionTextColor = clHighlightText
      SelectionRectangle = False
      SelectionResizer = False
      SelectionRTFKeep = False
      HintShowCells = False
      HintShowLargeText = False
      HintShowSizing = False
      PrintSettings.FooterSize = 0
      PrintSettings.HeaderSize = 0
      PrintSettings.Time = ppNone
      PrintSettings.Date = ppNone
      PrintSettings.DateFormat = 'dd/mm/yyyy'
      PrintSettings.PageNr = ppNone
      PrintSettings.Title = ppNone
      PrintSettings.Font.Charset = DEFAULT_CHARSET
      PrintSettings.Font.Color = clWindowText
      PrintSettings.Font.Height = -11
      PrintSettings.Font.Name = 'MS Sans Serif'
      PrintSettings.Font.Style = []
      PrintSettings.HeaderFont.Charset = DEFAULT_CHARSET
      PrintSettings.HeaderFont.Color = clWindowText
      PrintSettings.HeaderFont.Height = -11
      PrintSettings.HeaderFont.Name = 'MS Sans Serif'
      PrintSettings.HeaderFont.Style = []
      PrintSettings.FooterFont.Charset = DEFAULT_CHARSET
      PrintSettings.FooterFont.Color = clWindowText
      PrintSettings.FooterFont.Height = -11
      PrintSettings.FooterFont.Name = 'MS Sans Serif'
      PrintSettings.FooterFont.Style = []
      PrintSettings.Borders = pbNoborder
      PrintSettings.BorderStyle = psSolid
      PrintSettings.Centered = False
      PrintSettings.RepeatFixedRows = False
      PrintSettings.RepeatFixedCols = False
      PrintSettings.LeftSize = 0
      PrintSettings.RightSize = 0
      PrintSettings.ColumnSpacing = 0
      PrintSettings.RowSpacing = 0
      PrintSettings.TitleSpacing = 0
      PrintSettings.Orientation = poPortrait
      PrintSettings.PageNumberOffset = 0
      PrintSettings.MaxPagesOffset = 0
      PrintSettings.FixedWidth = 0
      PrintSettings.FixedHeight = 0
      PrintSettings.UseFixedHeight = False
      PrintSettings.UseFixedWidth = False
      PrintSettings.FitToPage = fpNever
      PrintSettings.PageNumSep = '/'
      PrintSettings.NoAutoSize = False
      PrintSettings.NoAutoSizeRow = False
      PrintSettings.PrintGraphics = False
      HTMLSettings.Width = 100
      HTMLSettings.XHTML = False
      Navigation.AdvanceDirection = adLeftRight
      Navigation.InsertPosition = pInsertBefore
      Navigation.HomeEndKey = heFirstLastColumn
      Navigation.TabToNextAtEnd = False
      Navigation.TabAdvanceDirection = adLeftRight
      ColumnSize.Location = clRegistry
      CellNode.Color = clSilver
      CellNode.NodeColor = clBlack
      CellNode.ShowTree = False
      MaxEditLength = 0
      IntelliPan = ipVertical
      URLColor = clBlue
      URLShow = False
      URLFull = False
      URLEdit = False
      ScrollType = ssNormal
      ScrollColor = clNone
      ScrollWidth = 17
      ScrollSynch = False
      ScrollProportional = False
      ScrollHints = shNone
      OemConvert = False
      FixedFooters = 0
      FixedRightCols = 0
      FixedColWidth = 307
      FixedRowHeight = 25
      FixedFont.Charset = DEFAULT_CHARSET
      FixedFont.Color = clWindowText
      FixedFont.Height = -13
      FixedFont.Name = #45208#45588#44256#46357
      FixedFont.Style = []
      FixedAsButtons = False
      FloatFormat = '%.2f'
      IntegralHeight = False
      WordWrap = False
      ColumnHeaders.Strings = (
        #44160#51652#54637#47785
        #54637#47785
        #45800#52404#52397#44396
        #44060#51064#52397#44396
        #49688#47049
        'DC'#50984
        #51068#48152#49688#44032
        #51032#48372#52397#44396
        #53945#44160#49688#44032)
      Lookup = False
      LookupCaseSensitive = False
      LookupHistory = False
      ShowSelection = False
      BackGround.Top = 0
      BackGround.Left = 0
      BackGround.Display = bdTile
      BackGround.Cells = bcNormal
      Filter = <>
      ColWidths = (
        307
        98
        151
        124
        76
        100
        94
        134
        142)
    end
    object pn_Panel004: TFlatPanel
      Left = 1
      Top = 827
      Width = 1679
      Height = 54
      ParentColor = True
      Align = alBottom
      TabOrder = 16
      UseDockManager = True
      object Label19: TLabel
        Left = 3
        Top = 4
        Width = 76
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #52509#51652#47308#48708
        Layout = tlCenter
      end
      object Label20: TLabel
        Left = 158
        Top = 4
        Width = 79
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #45800#52404#52397#44396
        Layout = tlCenter
      end
      object Label21: TLabel
        Left = 316
        Top = 4
        Width = 79
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #44060#51064#52397#44396
        Layout = tlCenter
      end
      object Label22: TLabel
        Left = 474
        Top = 4
        Width = 79
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #51032#48372#52397#44396
        Layout = tlCenter
      end
      object Label23: TLabel
        Left = 632
        Top = 4
        Width = 79
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #44060#51064#48120#49688
        Layout = tlCenter
      end
      object FlaTFlatPanel88: TLabel
        Left = 790
        Top = 4
        Width = 79
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #49440#49688#44552
        Layout = tlCenter
      end
      object FlaTFlatPanel89: TLabel
        Left = 948
        Top = 4
        Width = 79
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #44160#51652#44428#44552#50529
        Layout = tlCenter
      end
      object FlaTFlatPanel90: TLabel
        Left = 1106
        Top = 4
        Width = 79
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #44160#51652#44428#54032#47588
        Layout = tlCenter
      end
      object FlaTFlatPanel91: TLabel
        Left = 1269
        Top = 4
        Width = 79
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #49688#45225#50696#50808#44552#50529
        Layout = tlCenter
      end
      object FlaTFlatPanel92: TLabel
        Left = 632
        Top = 28
        Width = 79
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #52852#46300#49688#45225
        Layout = tlCenter
      end
      object FlaTFlatPanel93: TLabel
        Left = 790
        Top = 28
        Width = 79
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #54788#44552#49688#45225
        Layout = tlCenter
      end
      object FlaTFlatPanel94: TLabel
        Left = 948
        Top = 28
        Width = 79
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #54872#48520#44552#50529
        Layout = tlCenter
      end
      object FlaTFlatPanel95: TLabel
        Left = 1106
        Top = 28
        Width = 79
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #49688#45225#44552#50529
        Layout = tlCenter
      end
      object FlaTFlatPanel96: TLabel
        Left = 1269
        Top = 28
        Width = 79
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #44277#45800#44160#51652#52264#44048
        Layout = tlCenter
      end
      object FlatEdit9: TFlatEdit
        Left = 82
        Top = 4
        Width = 80
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 0
      end
      object FlatEdit10: TFlatEdit
        Left = 240
        Top = 4
        Width = 80
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 1
      end
      object FlatEdit11: TFlatEdit
        Left = 398
        Top = 4
        Width = 80
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 2
      end
      object FlatEdit12: TFlatEdit
        Left = 556
        Top = 4
        Width = 80
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 4
      end
      object FlatEdit13: TFlatEdit
        Left = 714
        Top = 4
        Width = 80
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 7
      end
      object FlatEdit38: TFlatEdit
        Left = 872
        Top = 4
        Width = 80
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 10
      end
      object FlatEdit39: TFlatEdit
        Left = 1030
        Top = 4
        Width = 80
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 13
      end
      object FlatEdit40: TFlatEdit
        Left = 1188
        Top = 4
        Width = 80
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 3
      end
      object FlatEdit41: TFlatEdit
        Left = 1351
        Top = 4
        Width = 80
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 5
      end
      object FlatEdit42: TFlatEdit
        Left = 714
        Top = 28
        Width = 80
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 6
      end
      object FlatEdit43: TFlatEdit
        Left = 872
        Top = 28
        Width = 80
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 8
      end
      object FlatEdit44: TFlatEdit
        Left = 1030
        Top = 28
        Width = 80
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 9
      end
      object FlatEdit45: TFlatEdit
        Left = 1188
        Top = 28
        Width = 80
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 11
      end
      object FlatEdit46: TFlatEdit
        Left = 1351
        Top = 28
        Width = 80
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 12
      end
    end
  end
end
