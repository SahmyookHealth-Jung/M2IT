object Form38: TForm38
  Left = 2218
  Top = 137
  Width = 1563
  Height = 855
  ActiveControl = FlatRadioButton39
  Caption = #54364#51201#51109#44592#48324' '#54032#51221#54788#54889' [VHMGBBZ046S]'
  Color = clWhite
  Font.Charset = ANSI_CHARSET
  Font.Color = clWindowText
  Font.Height = -13
  Font.Name = #45208#45588#44256#46357
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 15
  object FlatPanel4: TFlatPanel
    Left = 17
    Top = 31
    Width = 858
    Height = 542
    ParentColor = True
    TabOrder = 0
    UseDockManager = True
    object FlatPanel2: TFlatPanel
      Left = 1
      Top = 124
      Width = 856
      Height = 38
      ParentColor = True
      TabOrder = 4
      UseDockManager = True
      object FlatLabel3: TFlatLabel
        Left = 6
        Top = 5
        Width = 129
        Height = 25
        Alignment = taRightJustify
        TextBorder = 2
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #54364#51201#51109#44592#48324' '#54032#51221#54788#54889
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = True
        ShowEssential = False
      end
    end
    object FlatPanel6: TFlatPanel
      Left = 1
      Top = 89
      Width = 856
      Height = 35
      ParentColor = True
      TabOrder = 3
      UseDockManager = True
    end
    object FlatPanel3: TFlatPanel
      Left = 1
      Top = 1
      Width = 856
      Height = 89
      ParentColor = True
      TabOrder = 0
      UseDockManager = True
      object FlatLabel1: TFlatLabel
        Left = 5
        Top = 3
        Width = 65
        Height = 25
        Alignment = taRightJustify
        TextBorder = 0
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #49468#53552#44396#48516
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = False
        ShowEssential = True
      end
      object FlatLabel6: TFlatLabel
        Left = 5
        Top = 29
        Width = 65
        Height = 25
        Alignment = taRightJustify
        TextBorder = 0
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #51217#49688#44396#48516
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = False
        ShowEssential = True
      end
      object FlatLabel7: TFlatLabel
        Left = 224
        Top = 3
        Width = 65
        Height = 25
        Alignment = taRightJustify
        TextBorder = 0
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #49324#50629#45380#46020
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = False
        ShowEssential = True
      end
      object FlatLabel8: TFlatLabel
        Left = 211
        Top = 29
        Width = 78
        Height = 25
        Alignment = taRightJustify
        TextBorder = 0
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #53945#44160#49324#50629#51109
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = False
        ShowEssential = True
      end
      object FlatLabel2: TFlatLabel
        Left = 225
        Top = 58
        Width = 65
        Height = 25
        Alignment = taRightJustify
        TextBorder = 0
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #54032#51221#44396#48516
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = False
        ShowEssential = True
      end
      object FlatLabel4: TFlatLabel
        Left = 4
        Top = 58
        Width = 65
        Height = 25
        Alignment = taRightJustify
        TextBorder = 0
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #44228#53685
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = False
        ShowEssential = True
      end
      object FlatButton1: TFlatButton
        Left = 779
        Top = 60
        Width = 72
        Height = 23
        Color = clSilver
        Caption = #51312#54924
        ParentColor = False
        TabOrder = 0
      end
      object FlatSpinEditInteger2: TFlatSpinEditInteger
        Left = 295
        Top = 5
        Width = 64
        Height = 23
        ColorFlat = clWhite
        AutoSize = False
        MaxValue = 0
        MinValue = 0
        TabOrder = 1
        Value = 2026
      end
      object FlatEdit1: TFlatEdit
        Left = 295
        Top = 31
        Width = 104
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 2
      end
      object FlatPanel17: TFlatPanel
        Left = 295
        Top = 61
        Width = 402
        Height = 22
        ParentColor = True
        TabOrder = 3
        UseDockManager = True
        object FlatRadioButton38: TFlatRadioButton
          Left = 62
          Top = 2
          Width = 41
          Height = 17
          Caption = 'C1'
          TabOrder = 0
        end
        object FlatRadioButton39: TFlatRadioButton
          Left = 114
          Top = 2
          Width = 41
          Height = 17
          Caption = 'C2'
          TabOrder = 1
        end
        object FlatRadioButton40: TFlatRadioButton
          Left = 163
          Top = 2
          Width = 41
          Height = 17
          Caption = 'CN'
          TabOrder = 2
        end
        object FlatRadioButton42: TFlatRadioButton
          Left = 312
          Top = 2
          Width = 41
          Height = 17
          Caption = 'DN'
          TabOrder = 3
        end
        object FlatRadioButton43: TFlatRadioButton
          Left = 264
          Top = 2
          Width = 41
          Height = 17
          Caption = 'D2'
          TabOrder = 4
        end
        object FlatRadioButton44: TFlatRadioButton
          Left = 214
          Top = 2
          Width = 41
          Height = 17
          Caption = 'D1'
          TabOrder = 5
        end
        object FlatRadioButton46: TFlatRadioButton
          Left = 362
          Top = 2
          Width = 31
          Height = 17
          Caption = 'R'
          TabOrder = 6
        end
        object FlatRadioButton1: TFlatRadioButton
          Left = 7
          Top = 2
          Width = 41
          Height = 17
          Caption = #51204#52404
          TabOrder = 7
        end
      end
      object FlatSpinEditInteger1: TFlatSpinEditInteger
        Left = 400
        Top = 31
        Width = 47
        Height = 23
        ColorFlat = clWhite
        AutoSize = False
        MaxValue = 0
        MinValue = 0
        TabOrder = 4
        Value = 12
      end
      object FlatComboBox1: TFlatComboBox
        Left = 449
        Top = 31
        Width = 248
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 5
        ItemIndex = -1
      end
      object FlatComboBox5: TFlatComboBox
        Left = 76
        Top = 5
        Width = 102
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 6
        ItemIndex = -1
      end
      object FlatComboBox6: TFlatComboBox
        Left = 76
        Top = 31
        Width = 102
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 7
        ItemIndex = -1
      end
      object FlatPanel1: TFlatPanel
        Left = 76
        Top = 59
        Width = 102
        Height = 23
        ParentColor = True
        TabOrder = 8
        UseDockManager = True
        object FlatCheckBox1: TFlatCheckBox
          Left = 5
          Top = 2
          Width = 14
          Height = 17
          TabOrder = 0
          TabStop = True
        end
        object FlatComboBox3: TFlatComboBox
          Left = 20
          Top = 0
          Width = 82
          Height = 23
          Color = clWindow
          ItemHeight = 15
          TabOrder = 1
          Text = #51204#52404
          ItemIndex = -1
        end
      end
    end
    object FlatComboBox2: TFlatComboBox
      Left = 779
      Top = 95
      Width = 72
      Height = 23
      Color = clWindow
      ItemHeight = 15
      TabOrder = 1
      Text = '  Action'
      ItemIndex = -1
    end
    object FlatButton2: TFlatButton
      Left = 770
      Top = 118
      Width = 81
      Height = 23
      Caption = #50641#49472#45796#50868#47196#46300
      TabOrder = 2
    end
    object FlatPanel14: TFlatPanel
      Left = 1
      Top = 162
      Width = 856
      Height = 379
      ParentColor = True
      TabOrder = 5
      UseDockManager = True
      object AdvStringGrid2: TAdvStringGrid
        Left = 1
        Top = 1
        Width = 854
        Height = 377
        Cursor = crDefault
        Align = alClient
        ColCount = 10
        DefaultRowHeight = 25
        DefaultDrawing = False
        FixedCols = 0
        RowCount = 40
        FixedRows = 1
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'Tahoma'
        Font.Style = []
        GridLineWidth = 1
        Options = [goFixedVertLine, goFixedHorzLine, goVertLine, goHorzLine, goRangeSelect, goDrawFocusSelected]
        ParentFont = False
        TabOrder = 0
        GridLineColor = clSilver
        ActiveCellShow = False
        ActiveCellFont.Charset = DEFAULT_CHARSET
        ActiveCellFont.Color = clWindowText
        ActiveCellFont.Height = -11
        ActiveCellFont.Name = 'MS Sans Serif'
        ActiveCellFont.Style = [fsBold]
        ActiveCellColor = clGray
        Bands.PrimaryColor = clInfoBk
        Bands.PrimaryLength = 1
        Bands.SecondaryColor = clWindow
        Bands.SecondaryLength = 1
        Bands.Print = False
        AutoNumAlign = False
        AutoSize = False
        VAlignment = vtaTop
        EnhTextSize = False
        EnhRowColMove = False
        SizeWithForm = False
        Multilinecells = False
        DragDropSettings.OleAcceptFiles = True
        DragDropSettings.OleAcceptText = True
        SortSettings.AutoColumnMerge = False
        SortSettings.Column = 0
        SortSettings.Show = False
        SortSettings.IndexShow = False
        SortSettings.IndexColor = clYellow
        SortSettings.Full = True
        SortSettings.SingleColumn = False
        SortSettings.IgnoreBlanks = False
        SortSettings.BlankPos = blFirst
        SortSettings.AutoFormat = True
        SortSettings.Direction = sdAscending
        SortSettings.FixedCols = False
        SortSettings.NormalCellsOnly = False
        SortSettings.Row = 0
        FloatingFooter.Color = clBtnFace
        FloatingFooter.Column = 0
        FloatingFooter.FooterStyle = fsFixedLastRow
        FloatingFooter.Visible = False
        ControlLook.Color = clBlack
        ControlLook.CheckSize = 15
        ControlLook.RadioSize = 10
        ControlLook.ControlStyle = csClassic
        ControlLook.FlatButton = False
        EnableBlink = False
        EnableHTML = True
        EnableWheel = True
        Flat = False
        HintColor = clInfoBk
        SelectionColor = clHighlight
        SelectionTextColor = clHighlightText
        SelectionRectangle = False
        SelectionResizer = False
        SelectionRTFKeep = False
        HintShowCells = False
        HintShowLargeText = False
        HintShowSizing = False
        PrintSettings.FooterSize = 0
        PrintSettings.HeaderSize = 0
        PrintSettings.Time = ppNone
        PrintSettings.Date = ppNone
        PrintSettings.DateFormat = 'dd/mm/yyyy'
        PrintSettings.PageNr = ppNone
        PrintSettings.Title = ppNone
        PrintSettings.Font.Charset = DEFAULT_CHARSET
        PrintSettings.Font.Color = clWindowText
        PrintSettings.Font.Height = -11
        PrintSettings.Font.Name = 'MS Sans Serif'
        PrintSettings.Font.Style = []
        PrintSettings.HeaderFont.Charset = DEFAULT_CHARSET
        PrintSettings.HeaderFont.Color = clWindowText
        PrintSettings.HeaderFont.Height = -11
        PrintSettings.HeaderFont.Name = 'MS Sans Serif'
        PrintSettings.HeaderFont.Style = []
        PrintSettings.FooterFont.Charset = DEFAULT_CHARSET
        PrintSettings.FooterFont.Color = clWindowText
        PrintSettings.FooterFont.Height = -11
        PrintSettings.FooterFont.Name = 'MS Sans Serif'
        PrintSettings.FooterFont.Style = []
        PrintSettings.Borders = pbNoborder
        PrintSettings.BorderStyle = psSolid
        PrintSettings.Centered = False
        PrintSettings.RepeatFixedRows = False
        PrintSettings.RepeatFixedCols = False
        PrintSettings.LeftSize = 0
        PrintSettings.RightSize = 0
        PrintSettings.ColumnSpacing = 0
        PrintSettings.RowSpacing = 0
        PrintSettings.TitleSpacing = 0
        PrintSettings.Orientation = poPortrait
        PrintSettings.PageNumberOffset = 0
        PrintSettings.MaxPagesOffset = 0
        PrintSettings.FixedWidth = 0
        PrintSettings.FixedHeight = 0
        PrintSettings.UseFixedHeight = False
        PrintSettings.UseFixedWidth = False
        PrintSettings.FitToPage = fpNever
        PrintSettings.PageNumSep = '/'
        PrintSettings.NoAutoSize = False
        PrintSettings.NoAutoSizeRow = False
        PrintSettings.PrintGraphics = False
        HTMLSettings.Width = 100
        HTMLSettings.XHTML = False
        Navigation.AdvanceDirection = adLeftRight
        Navigation.InsertPosition = pInsertBefore
        Navigation.HomeEndKey = heFirstLastColumn
        Navigation.TabToNextAtEnd = False
        Navigation.TabAdvanceDirection = adLeftRight
        ColumnSize.Location = clRegistry
        CellNode.Color = clSilver
        CellNode.NodeColor = clBlack
        CellNode.ShowTree = False
        MaxEditLength = 0
        IntelliPan = ipVertical
        URLColor = clBlue
        URLShow = False
        URLFull = False
        URLEdit = False
        ScrollType = ssNormal
        ScrollColor = clNone
        ScrollWidth = 17
        ScrollSynch = False
        ScrollProportional = False
        ScrollHints = shNone
        OemConvert = False
        FixedFooters = 0
        FixedRightCols = 0
        FixedColWidth = 21
        FixedRowHeight = 32
        FixedFont.Charset = DEFAULT_CHARSET
        FixedFont.Color = clWindowText
        FixedFont.Height = -13
        FixedFont.Name = #45208#45588#44256#46357
        FixedFont.Style = []
        FixedAsButtons = False
        FloatFormat = '%.2f'
        IntegralHeight = False
        WordWrap = False
        ColumnHeaders.Strings = (
          ''
          #44144#47000#52376#47749
          #48512#49436
          #49324#48264
          #49457#47749
          #51452#48124#48264#54840
          #44277#51221
          #51649#51333
          #54032#51221
          #54364#51201#51109#44592#47749)
        Lookup = False
        LookupCaseSensitive = False
        LookupHistory = False
        ShowSelection = False
        BackGround.Top = 0
        BackGround.Left = 0
        BackGround.Display = bdTile
        BackGround.Cells = bcNormal
        Filter = <>
        ColWidths = (
          21
          62
          97
          92
          66
          108
          91
          86
          77
          216)
        RowHeights = (
          32
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25)
      end
    end
  end
end
