object Form3: TForm3
  Left = -32
  Top = 20
  Width = 1550
  Height = 814
  Caption = #53945#49688#44148#44053#51652#45800#44208#44284#54364' '#53685#44228' [VHMGBBZ049S]'
  Color = clWhite
  Font.Charset = ANSI_CHARSET
  Font.Color = clWindowText
  Font.Height = -13
  Font.Name = #45208#45588#44256#46357
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 15
  object FlatPanel4: TFlatPanel
    Left = 39
    Top = 63
    Width = 1490
    Height = 578
    ParentColor = True
    TabOrder = 0
    UseDockManager = True
    object FlatPanel2: TFlatPanel
      Left = 1
      Top = 159
      Width = 1488
      Height = 38
      ParentColor = True
      TabOrder = 3
      UseDockManager = True
      object FlatLabel3: TFlatLabel
        Left = 7
        Top = 5
        Width = 105
        Height = 25
        Alignment = taRightJustify
        TextBorder = 2
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #44148#44053#51652#45800#44208#44284#54364
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = True
        ShowEssential = False
      end
    end
    object FlatPanel6: TFlatPanel
      Left = 1
      Top = 121
      Width = 1488
      Height = 38
      ParentColor = True
      TabOrder = 2
      UseDockManager = True
    end
    object FlatComboBox2: TFlatComboBox
      Left = 1409
      Top = 130
      Width = 72
      Height = 23
      Color = clWindow
      ItemHeight = 15
      TabOrder = 0
      Text = '  Action'
      ItemIndex = -1
    end
    object FlatButton2: TFlatButton
      Left = 1400
      Top = 153
      Width = 81
      Height = 23
      Caption = #50641#49472#45796#50868#47196#46300
      TabOrder = 1
    end
    object FlatPanel14: TFlatPanel
      Left = 1
      Top = 197
      Width = 1488
      Height = 380
      ParentColor = True
      TabOrder = 4
      UseDockManager = True
      object AdvStringGrid2: TAdvStringGrid
        Left = 1
        Top = 1
        Width = 1486
        Height = 378
        Cursor = crDefault
        Align = alClient
        ColCount = 18
        DefaultRowHeight = 25
        DefaultDrawing = False
        FixedCols = 0
        RowCount = 40
        FixedRows = 1
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'Tahoma'
        Font.Style = []
        GridLineWidth = 1
        Options = [goFixedVertLine, goFixedHorzLine, goVertLine, goHorzLine, goRangeSelect, goDrawFocusSelected]
        ParentFont = False
        TabOrder = 0
        GridLineColor = clSilver
        ActiveCellShow = False
        ActiveCellFont.Charset = DEFAULT_CHARSET
        ActiveCellFont.Color = clWindowText
        ActiveCellFont.Height = -11
        ActiveCellFont.Name = 'MS Sans Serif'
        ActiveCellFont.Style = [fsBold]
        ActiveCellColor = clGray
        Bands.PrimaryColor = clInfoBk
        Bands.PrimaryLength = 1
        Bands.SecondaryColor = clWindow
        Bands.SecondaryLength = 1
        Bands.Print = False
        AutoNumAlign = False
        AutoSize = False
        VAlignment = vtaTop
        EnhTextSize = False
        EnhRowColMove = False
        SizeWithForm = False
        Multilinecells = False
        DragDropSettings.OleAcceptFiles = True
        DragDropSettings.OleAcceptText = True
        SortSettings.AutoColumnMerge = False
        SortSettings.Column = 0
        SortSettings.Show = False
        SortSettings.IndexShow = False
        SortSettings.IndexColor = clYellow
        SortSettings.Full = True
        SortSettings.SingleColumn = False
        SortSettings.IgnoreBlanks = False
        SortSettings.BlankPos = blFirst
        SortSettings.AutoFormat = True
        SortSettings.Direction = sdAscending
        SortSettings.FixedCols = False
        SortSettings.NormalCellsOnly = False
        SortSettings.Row = 0
        FloatingFooter.Color = clBtnFace
        FloatingFooter.Column = 0
        FloatingFooter.FooterStyle = fsFixedLastRow
        FloatingFooter.Visible = False
        ControlLook.Color = clBlack
        ControlLook.CheckSize = 15
        ControlLook.RadioSize = 10
        ControlLook.ControlStyle = csClassic
        ControlLook.FlatButton = False
        EnableBlink = False
        EnableHTML = True
        EnableWheel = True
        Flat = False
        HintColor = clInfoBk
        SelectionColor = clHighlight
        SelectionTextColor = clHighlightText
        SelectionRectangle = False
        SelectionResizer = False
        SelectionRTFKeep = False
        HintShowCells = False
        HintShowLargeText = False
        HintShowSizing = False
        PrintSettings.FooterSize = 0
        PrintSettings.HeaderSize = 0
        PrintSettings.Time = ppNone
        PrintSettings.Date = ppNone
        PrintSettings.DateFormat = 'dd/mm/yyyy'
        PrintSettings.PageNr = ppNone
        PrintSettings.Title = ppNone
        PrintSettings.Font.Charset = DEFAULT_CHARSET
        PrintSettings.Font.Color = clWindowText
        PrintSettings.Font.Height = -11
        PrintSettings.Font.Name = 'MS Sans Serif'
        PrintSettings.Font.Style = []
        PrintSettings.HeaderFont.Charset = DEFAULT_CHARSET
        PrintSettings.HeaderFont.Color = clWindowText
        PrintSettings.HeaderFont.Height = -11
        PrintSettings.HeaderFont.Name = 'MS Sans Serif'
        PrintSettings.HeaderFont.Style = []
        PrintSettings.FooterFont.Charset = DEFAULT_CHARSET
        PrintSettings.FooterFont.Color = clWindowText
        PrintSettings.FooterFont.Height = -11
        PrintSettings.FooterFont.Name = 'MS Sans Serif'
        PrintSettings.FooterFont.Style = []
        PrintSettings.Borders = pbNoborder
        PrintSettings.BorderStyle = psSolid
        PrintSettings.Centered = False
        PrintSettings.RepeatFixedRows = False
        PrintSettings.RepeatFixedCols = False
        PrintSettings.LeftSize = 0
        PrintSettings.RightSize = 0
        PrintSettings.ColumnSpacing = 0
        PrintSettings.RowSpacing = 0
        PrintSettings.TitleSpacing = 0
        PrintSettings.Orientation = poPortrait
        PrintSettings.PageNumberOffset = 0
        PrintSettings.MaxPagesOffset = 0
        PrintSettings.FixedWidth = 0
        PrintSettings.FixedHeight = 0
        PrintSettings.UseFixedHeight = False
        PrintSettings.UseFixedWidth = False
        PrintSettings.FitToPage = fpNever
        PrintSettings.PageNumSep = '/'
        PrintSettings.NoAutoSize = False
        PrintSettings.NoAutoSizeRow = False
        PrintSettings.PrintGraphics = False
        HTMLSettings.Width = 100
        HTMLSettings.XHTML = False
        Navigation.AdvanceDirection = adLeftRight
        Navigation.InsertPosition = pInsertBefore
        Navigation.HomeEndKey = heFirstLastColumn
        Navigation.TabToNextAtEnd = False
        Navigation.TabAdvanceDirection = adLeftRight
        ColumnSize.Location = clRegistry
        CellNode.Color = clSilver
        CellNode.NodeColor = clBlack
        CellNode.ShowTree = False
        MaxEditLength = 0
        IntelliPan = ipVertical
        URLColor = clBlue
        URLShow = False
        URLFull = False
        URLEdit = False
        ScrollType = ssNormal
        ScrollColor = clNone
        ScrollWidth = 17
        ScrollSynch = False
        ScrollProportional = False
        ScrollHints = shNone
        OemConvert = False
        FixedFooters = 0
        FixedRightCols = 0
        FixedColWidth = 40
        FixedRowHeight = 32
        FixedFont.Charset = DEFAULT_CHARSET
        FixedFont.Color = clWindowText
        FixedFont.Height = -13
        FixedFont.Name = #45208#45588#44256#46357
        FixedFont.Style = []
        FixedAsButtons = False
        FloatFormat = '%.2f'
        IntegralHeight = False
        WordWrap = False
        ColumnHeaders.Strings = (
          #50672#48264
          #44144#47000#52376#47749
          #44160#51652#51068#51088
          #51217#49688#48264#54840
          #51060#47492
          #49457#48324
          #49373#45380#50900#51068
          #52712#44553#47932#51656#48143#49548#44204
          #45824#54364#54032#51221
          'CN'
          'C2'
          'C1'
          'DN'
          'D1'
          'D2'
          #51656#48337#53076#46300'1'
          #51656#48337#53076#46300'2'
          #51656#48337#53076#46300'3')
        Lookup = False
        LookupCaseSensitive = False
        LookupHistory = False
        ShowSelection = False
        BackGround.Top = 0
        BackGround.Left = 0
        BackGround.Display = bdTile
        BackGround.Cells = bcNormal
        Filter = <>
        ColWidths = (
          40
          63
          97
          92
          61
          51
          75
          95
          65
          82
          69
          79
          66
          72
          85
          121
          142
          121)
        RowHeights = (
          32
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25)
      end
    end
    object FlatPanel3: TFlatPanel
      Left = 1
      Top = 1
      Width = 1488
      Height = 120
      ParentColor = True
      TabOrder = 5
      UseDockManager = True
      object FlatLabel1: TFlatLabel
        Left = 8
        Top = 4
        Width = 65
        Height = 25
        Alignment = taRightJustify
        TextBorder = 0
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #51089#50629#49440#53469
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = False
        ShowEssential = True
      end
      object Label6: TLabel
        Left = 23
        Top = 31
        Width = 49
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #49468#53552#44396#48516
        Layout = tlCenter
      end
      object Label7: TLabel
        Left = 190
        Top = 32
        Width = 49
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #51217#49688#44396#48516
        Layout = tlCenter
      end
      object Label8: TLabel
        Left = 22
        Top = 58
        Width = 49
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #44144#47000#52376#47749
        Layout = tlCenter
      end
      object Label10: TLabel
        Left = 8
        Top = 87
        Width = 64
        Height = 20
        Alignment = taRightJustify
        AutoSize = False
        Caption = #49324#50629#51109#48264#54840
        Layout = tlCenter
      end
      object Label11: TLabel
        Left = 516
        Top = 33
        Width = 25
        Height = 23
        Alignment = taCenter
        AutoSize = False
        Caption = '~'
        Layout = tlCenter
      end
      object Label12: TLabel
        Left = 357
        Top = 32
        Width = 49
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #51217#49688#51068#51088
        Layout = tlCenter
      end
      object FlatLabel2: TFlatLabel
        Left = 655
        Top = 62
        Width = 49
        Height = 23
        Alignment = taRightJustify
        TextBorder = 0
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #53945#44160#44396#48516
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = False
        ShowEssential = False
      end
      object FlatLabel4: TFlatLabel
        Left = 655
        Top = 5
        Width = 49
        Height = 23
        Alignment = taRightJustify
        TextBorder = 0
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #51221#47148#49692#49436
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = False
        ShowEssential = False
      end
      object FlatLabel6: TFlatLabel
        Left = 359
        Top = 3
        Width = 49
        Height = 25
        Alignment = taRightJustify
        TextBorder = 0
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #51109#49548#44396#48516
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = False
        ShowEssential = False
      end
      object Label1: TLabel
        Left = 655
        Top = 32
        Width = 49
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #51217#49688#48264#54840
        Layout = tlCenter
      end
      object Label2: TLabel
        Left = 812
        Top = 33
        Width = 25
        Height = 23
        Alignment = taCenter
        AutoSize = False
        Caption = '~'
        Layout = tlCenter
      end
      object FlatButton1: TFlatButton
        Left = 1408
        Top = 91
        Width = 72
        Height = 23
        Color = clSilver
        Caption = #51312#54924
        ParentColor = False
        TabOrder = 0
      end
      object FlatPanel1: TFlatPanel
        Left = 79
        Top = 6
        Width = 242
        Height = 23
        ParentColor = True
        TabOrder = 1
        UseDockManager = True
        object FlatRadioButton1: TFlatRadioButton
          Left = 4
          Top = 2
          Width = 97
          Height = 17
          Caption = #44144#47000#52376'/'#44228#50557#48324
          TabOrder = 0
        end
        object FlatRadioButton2: TFlatRadioButton
          Left = 100
          Top = 2
          Width = 68
          Height = 17
          Caption = #51217#49688#51068#48324
          TabOrder = 1
        end
        object FlatRadioButton15: TFlatRadioButton
          Left = 172
          Top = 3
          Width = 68
          Height = 17
          Caption = #44144#47000#52376#48324
          TabOrder = 2
        end
      end
      object FlatComboBox8: TFlatComboBox
        Left = 246
        Top = 33
        Width = 102
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 2
        ItemIndex = -1
      end
      object FlatSpinEditInteger2: TFlatSpinEditInteger
        Left = 188
        Top = 59
        Width = 64
        Height = 23
        ColorFlat = clWhite
        AutoSize = False
        MaxValue = 0
        MinValue = 0
        TabOrder = 3
        Value = 2026
      end
      object FlatEdit5: TFlatEdit
        Left = 79
        Top = 59
        Width = 104
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 4
      end
      object FlatComboBox9: TFlatComboBox
        Left = 255
        Top = 59
        Width = 388
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 5
        ItemIndex = -1
      end
      object FlatEdit1: TFlatEdit
        Left = 79
        Top = 87
        Width = 104
        Height = 23
        ColorFlat = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 6
      end
      object FlatPanel7: TFlatPanel
        Left = 712
        Top = 5
        Width = 275
        Height = 23
        ParentColor = True
        TabOrder = 7
        UseDockManager = True
        object FlatRadioButton28: TFlatRadioButton
          Left = 8
          Top = 2
          Width = 81
          Height = 17
          Caption = #51217#49688#48264#54840#49692
          TabOrder = 0
        end
        object FlatRadioButton29: TFlatRadioButton
          Left = 93
          Top = 3
          Width = 68
          Height = 17
          Caption = #49457#47749#49692
          TabOrder = 1
        end
        object FlatRadioButton30: TFlatRadioButton
          Left = 155
          Top = 2
          Width = 60
          Height = 17
          Caption = #48512#49436#49692
          TabOrder = 2
        end
        object FlatRadioButton31: TFlatRadioButton
          Left = 213
          Top = 2
          Width = 60
          Height = 17
          Caption = #49324#48264#49692
          TabOrder = 3
        end
      end
      object FlatPanel15: TFlatPanel
        Left = 711
        Top = 63
        Width = 193
        Height = 22
        ParentColor = True
        TabOrder = 8
        UseDockManager = True
        object FlatRadioButton33: TFlatRadioButton
          Left = 8
          Top = 2
          Width = 49
          Height = 17
          Caption = #51204#52404
          TabOrder = 0
        end
        object FlatRadioButton34: TFlatRadioButton
          Left = 53
          Top = 2
          Width = 60
          Height = 17
          Caption = #48176#52824#51204
          TabOrder = 1
        end
        object FlatRadioButton35: TFlatRadioButton
          Left = 113
          Top = 2
          Width = 68
          Height = 17
          Caption = #53945#49688#44160#51652
          TabOrder = 2
        end
      end
      object FlatSpinEditInteger1: TFlatSpinEditInteger
        Left = 188
        Top = 87
        Width = 64
        Height = 23
        ColorFlat = clWhite
        AutoSize = False
        MaxValue = 0
        MinValue = 0
        TabOrder = 9
        Value = 2026
      end
      object FlatComboBox1: TFlatComboBox
        Left = 255
        Top = 87
        Width = 388
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 10
        ItemIndex = -1
      end
      object FlatComboBox3: TFlatComboBox
        Left = 413
        Top = 33
        Width = 102
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 11
        ItemIndex = -1
      end
      object FlatComboBox4: TFlatComboBox
        Left = 540
        Top = 33
        Width = 102
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 12
        ItemIndex = -1
      end
      object FlatComboBox5: TFlatComboBox
        Left = 79
        Top = 32
        Width = 102
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 13
        ItemIndex = -1
      end
      object FlatPanel5: TFlatPanel
        Left = 413
        Top = 5
        Width = 193
        Height = 22
        ParentColor = True
        TabOrder = 14
        UseDockManager = True
        object FlatRadioButton3: TFlatRadioButton
          Left = 8
          Top = 2
          Width = 49
          Height = 17
          Caption = #51204#52404
          TabOrder = 0
        end
        object FlatRadioButton4: TFlatRadioButton
          Left = 61
          Top = 2
          Width = 52
          Height = 17
          Caption = #50896#45236
          TabOrder = 1
        end
        object FlatRadioButton5: TFlatRadioButton
          Left = 113
          Top = 2
          Width = 69
          Height = 17
          Caption = #52636#51109#44160#51652
          TabOrder = 2
        end
      end
      object FlatComboBox6: TFlatComboBox
        Left = 711
        Top = 33
        Width = 102
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 15
        ItemIndex = -1
      end
      object FlatComboBox7: TFlatComboBox
        Left = 836
        Top = 33
        Width = 102
        Height = 23
        Color = clWindow
        ItemHeight = 15
        TabOrder = 16
        ItemIndex = -1
      end
    end
  end
end
