unit VHMGBBZ043S;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, TFlatButtonUnit, TFlatRadioButtonUnit, TFlatEditUnit, StdCtrls,
  TFlatComboBoxUnit, TFlatCheckBoxUnit, TFlatSpinEditUnit, TFlatLabelUnit,
  ExtCtrls, TFlatPanelUnit;

type
  TForm36 = class(TForm)
    FlatPanel1: TFlatPanel;
    FlatPanel5: TFlatPanel;
    FlatPanel3: TFlatPanel;
    FlatLabel3: TFlatLabel;
    FlatLabel7: TFlatLabel;
    FlatLabel2: TFlatLabel;
    Label1: TLabel;
    FlatLabel1: TFlatLabel;
    FlatLabel4: TFlatLabel;
    FlatSpinEditInteger2: TFlatSpinEditInteger;
    FlatSpinEditInteger1: TFlatSpinEditInteger;
    pn_Panel013: TFlatPanel;
    FlatCheckBox7: TFlatCheckBox;
    FlatComboBox21: TFlatComboBox;
    FlatPanel4: TFlatPanel;
    FlatCheckBox1: TFlatCheckBox;
    FlatComboBox1: TFlatComboBox;
    FlatEdit5: TFlatEdit;
    FlatComboBox9: TFlatComboBox;
    FlatComboBox3: TFlatComboBox;
    FlatComboBox4: TFlatComboBox;
    FlatPanel7: TFlatPanel;
    FlatRadioButton3: TFlatRadioButton;
    FlatRadioButton4: TFlatRadioButton;
    FlatRadioButton5: TFlatRadioButton;
    FlatComboBox2: TFlatComboBox;
    FlatButton3: TFlatButton;
    FlatCheckBox2: TFlatCheckBox;
    FlatButton1: TFlatButton;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form36: TForm36;

implementation

{$R *.dfm}

end.
